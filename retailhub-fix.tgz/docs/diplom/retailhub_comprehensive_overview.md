# Полное руководство по архитектуре проекта RetailHub (Comprehensive Guide)

Этот документ предназначен для быстрого и глубокого погружения в проект. Ознакомившись с ним, вы полностью поймете бизнес-задачу, принципы работы каждого компонента, внутренние потоки данных и особенности технической реализации.

---

## 1. Концепция и Бизнес-задача

**RetailHub** — это event-driven (событийно-ориентированная) платформа для диспетчеризации консультантов в розничных магазинах электроники, одежды, DIY и других.
Концепция системы похожа на "Uber для консультантов":
1. **Клиент** находится в магазине, подходит к витрине (например, "Смартфоны") и сканирует размещенный там QR-код.
2. Система создает заявку и автоматически рассылает Push-уведомления на смартфоны свободных консультантов именно этого отдела.
3. Первый нажавший "Взять" направляется к клиенту. Клиент на своем телефоне видит в реальном времени статус "К вам подходит Иван Петров".
4. За соблюдением времени реакции следит **SLA-контроль**: если никто не берет заявку 3 минуты — идет повторный пуш, если 5 минут — штраф и эскалация Менеджеру магазина.

### Ключевые роли:
*   👤 **Клиент** — не авторизован (идентифицируется токеном сессии в браузере), может создавать, отменять и напоминать о заявке.
*   👨‍💼 **Консультант** — сотрудник со статусами `ACTIVE`, `BUSY`, `OFFLINE`. Получает уведомления, берет заявки в работу, закрывает их. Если смена не начата (`OFFLINE`), на стандартном `POST /requests/{id}/assign` возвращается отдельный HTTP-код `412`.
*   👔 **Менеджер** — управляет магазином, отделами, QR-кодами и просматривает аналитику. 

---

## 2. Глобальная Архитектура Системы

Проект реализован в парадигме **Микросервисной архитектуры** с асинхронным общением через шину данных (Apache Kafka).

```mermaid
graph TD
    classDef client fill:#f9f,stroke:#333,stroke-width:2px;
    classDef gateway fill:#e1f5fe,stroke:#0277bd,stroke-width:2px;
    classDef service fill:#e8f5e9,stroke:#2e7d32,stroke-width:2px;
    classDef db fill:#fff9c4,stroke:#fbc02d,stroke-width:2px;
    classDef bus fill:#ffccbc,stroke:#bf360c,stroke-width:2px;
    classDef external fill:#f3e5f5,stroke:#7b1fa2,stroke-width:2px;

    Client["📱 Клиент/Web App"]:::client
    MobileApp["📲 App Консультанта"]:::client
    Gateway["🌐 API Gateway (Сборка JWT, Rate Limiting)"]:::gateway

    Client -->|HTTPS| Gateway
    MobileApp -->|HTTPS / WSS| Gateway

    subgraph Микросервисы [Microservices Layer]
        direction TB
        AuthService["🔐 Auth Service"]:::service
        StoreService["🏪 Store Service"]:::service
        UserService["👨‍💼 User Service"]:::service
        ReqService["⚡ Request Service (Ядро)"]:::service
        NotifService["🔔 Notification Service"]:::service
        AnalyticsService["📊 Analytics Service"]:::service
        
        AuthDB[("Auth DB")]:::db
        StoreDB[("Store DB")]:::db
        UserDB[("User DB")]:::db
        ReqDB[("Request DB")]:::db
        NotifDB[("Notif DB")]:::db
        AnalyticsDB[("Timescale DB")]:::db

        AuthService <--> AuthDB
        StoreService <--> StoreDB
        UserService <--> UserDB
        ReqService <--> ReqDB
        NotifService <--> NotifDB
        AnalyticsService <--> AnalyticsDB
    end

    Gateway -->|REST| AuthService
    Gateway -->|REST| StoreService
    Gateway -->|REST| UserService
    Gateway -->|REST| ReqService
    Gateway -->|REST / WebSocket| NotifService
    Gateway -->|REST| AnalyticsService

    Kafka{{"🔥 Apache Kafka (Event Bus)"}}:::bus
    Redis[("🚀 Redis (Delay Queue & Cache)")]:::db

    %% Producer paths
    StoreService -. "store-events" .-> Kafka
    UserService -. "user-events" .-> Kafka
    ReqService -. "request-events" .-> Kafka

    %% Consumer paths
    Kafka -.->|Слушает| AuthService
    Kafka -.->|Слушает| UserService
    Kafka -.->|Слушает| ReqService
    Kafka -.->|Слушает| NotifService
    Kafka -.->|Слушает| AnalyticsService

    ReqService <-->|SLA Timers| Redis
    Gateway <-->|Rate Limit| Redis

    FCM["☁️ Firebase Cloud Messaging"]:::external
    NotifService -->|REST Push| FCM
```

---

## 3. Спецификация Микросервисов

Архитектура строго придерживается правила **Database-per-Service**: каждый сервис работает только со своей PostgreSQL базой данных. В проекте нет жестких связей на уровне БД и нет REST/HTTP вызовов из одного сервиса в другой.

| Сервис | Порт | База Данных | Описание и Ответственность |
|---|---|---|---|
| **api-gateway** | `8080` | Нет | Единая точка входа (Spring Cloud Gateway). Проверяет подпись JWT токенов (RS256), парсит `User-Id` и роли, преобразуя их во внутренние HTTP-заголовки. Обеспечивает Rate Limiting (Redis) и CORS. Проксирует WebSockets. |
| **auth-service** | `8081` | `auth_db` | Отвечает только за аутентификацию (Login/Refresh) и генерацию JWT. Слушает события `USER_CREATED` из Kafka, чтобы добавить логин и хеш пароля для новых сотрудников. Хранит приватный ключ. |
| **store-service** | `8082` | `store_db` | Каталог (Мастер-данные). Хранит адреса магазинов, отделы и привязанные к ним QR-коды для клиенского сканирования. Является только "Писателем" в Kafka (`store-events`), но ничего из неё не слушает. |
| **user-service** | `8083` | `user_db` | Персонал. Управляет профилями, сменами, матрицей компетенций (какой сотрудник где работает). Слушает `store-events` (копирует отделы себе) и `request-events` (калькулирует штрафы для опоздавших консультантов и меняет статус сотрудника на `BUSY`, когда тот берет заявку). |
| **request-service** | `8084` | `request_db` | Ядро системы: логика диспетчеризации и очередей заявок (SLA). Слушает `user-events` и `store-events`, чтобы хранить у себя "копии" QR-кодов и имена юзеров. За счет этого сервис не зависит от работоспособности других модулей во время потока заявок. |
| **notification-service**| `8085` | `notification_db`| Слушает `request-events` и мгновенно рассылает клиентам WebSocket события (обновляя статус в браузере), а консультантам — FCM пуши на мобильные. |
| **analytics-service** | `8086` | `analytics_db` | Слушает **все** каналы Kafka. Денормализует поток событий в структуру "Факт-Измерение" (Fact-Dimension), храня её в TimescaleDB для очень быстрой отдачи дашбордов менеджерам. |

---

## 4. Паттерны межсервисного взаимодействия и Apache Kafka

### 4.1. Почему Kafka? "Zero Sync Communication"
В классической микросервисной архитектуре при создании заявки `Request Service` должен был бы дернуть `Store Service` по REST, чтобы проверить QR-код, затем `User Service` чтобы найти активных консультантов, и `Notification Service` для отправки пуша. 
В такой архитектуре отказ одного из сервисов ведет к полному отказу бизнес-процесса.
В RetailHub сервисы **никогда не общаются друг с другом по HTTP**. Всё решается через Kafka.

### 4.2. Механизм Transactional Outbox
Что если база данных сохранила заявку сотрудника, но в момент попытки отправки `kafkaTemplate.send()` моргнула сеть или сервис упал (Out Of Memory)? Событие потеряется. 
Чтобы этого не было, используется паттерн **Transactional Outbox**:
1. Бизнес-метод (например, `createRequest`) в рамках одной `@Transactional` сохраняет заявку в таблицу `requests` и событие в `outbox_events`. Если что-то упадет — откатится и БД, и событие.
2. Отдельный планировщик `OutboxPublisher` каждые 100мс читает таблицу `outbox_events` и надежно доставляет их в Kafka (гарантия *At-Least-Once Delivery*).

### 4.3. Event-Carried State Transfer (Репликация)
Чтобы `Request Service` при сканировании QR-кода не делал HTTP-запрос к `Store Service` для проверки его валидности, используется паттерн реплик:
- Когда в `Store Service` создается QR-код, в Kafka улетает событие `QR_CODE_CREATED`.
- `Request Service` "слушает" это событие и добавляет QR в локальную таблицу `replica_qr_codes` в своей БД.
- Теперь валидация QR происходит мгновенно внутри `Request Service` без сетевых вызовов. 

---

## 5. Жизненный цикл заявок и Сценарии работы

В RetailHub реализована строгая Машина состояний (State Machine) заявки:

```mermaid
stateDiagram-v2
    [*] --> CREATED: Клиент сканирует QR
    CREATED --> WAITING: ⏱ 3 мин ожидания
    WAITING --> ESCALATED: ⏱ 5 мин ожидания 🚨
    
    CREATED --> ASSIGNED: Консультант "Взял!"
    WAITING --> ASSIGNED: Консультант "Взял!"
    ESCALATED --> ASSIGNED: Менеджер пнул консультанта
    
    ASSIGNED --> COMPLETED: Проблема решена 🎉
    ASSIGNED --> CREATED: Клиент меняет консультанта (REASSIGN)
    
    CREATED --> CANCELED: Клиент ушел
    WAITING --> CANCELED: Клиент ушел
    ASSIGNED --> CANCELED: Клиент ушел
```

### Сценарий Эскалации (Поэтапный разбор)
1. **[T = 0]** Клиент сканирует QR-код. API Gateway прокидывает запрос к `Request Service`. Сервис сохраняет `status=CREATED`, бросает в Kafka `REQUEST_CREATED` и записывает таймеры в Redis (см. раздел 6).
2. `Notification Service` ловит из Kafka `REQUEST_CREATED` и отправляет Push **всем** свободным (`ACTIVE`) консультантам целевого отдела.
3. Клиент закрыл вкладку и никто не взял заявку. 
4. **[T = +3 мин]** Redis отдает "протухший" таймер. `Request Service` обновляет `status=WAITING` и кидает в Kafka `REQUEST_WAITING`. `Notification Service` шлет повторные пуши-напоминания консультантам.
5. **[T = +5 мин]** SLA просрочен. Redis отдает таймер эскалации. `status=ESCALATED`. В Kafka летит `REQUEST_ESCALATED`. 
   - `Notification Service` кричит пушом Менеджеру: *"В отделе Телевизоров 5 минут игнорят клиента!"*.
   - `User Service` ловит это событие и увеличивает счетчик штрафов (`penalty_count`) всем консультантам этого отдела в базе.

---

## 6. Зачем в этом проекте Redis? (Детальное устройство SLA)

Если использовать классический `@Scheduled(fixedRate=5000)` в Spring, который бы каждые 5 секунд сканировал всю таблицу СУБД (PostgreSQL) `SELECT * FROM requests WHERE status='CREATED' AND created_at < NOW() - 3 minutes`, база очень быстро ляжет (Full Table Scan или высокая I/O нагрузка на индексы).

Redis, как in-memory база, используется для элегантного решения **SLA Delay Queue (Очередь отложенных событий)** с использованием структуры данных `ZSET` (Sorted Set).

### Механика SLA на Redis:
1. Во время создания заявки, `Request Service` атомарно делает команду в Redis:
   `ZADD sla:timers 1700000000000 "e1b2...:WAITING"` *(1700000000000 — это текущий Unix Timestamp + 3 минуты).*
2. В фоне `SlaWorker` делает пушинг Redis каждую секунду:
   `ZRANGEBYSCORE sla:timers 0 [Текущий_Timestamp]`.
3. Так как `ZSET` — это упорядоченный список, Redis находит все "созревшие" (просроченные) таймеры мгновенно (сложность `O(log N)`), а если очередь пуста, результат приходит за `O(1)`.
4. Сервис атомарно забирает таймер: `ZREM sla:timers "e1b2...:WAITING"`.
5. И ТОЛЬКО ПОСЛЕ ЭТОГО идет 1 легкий `SELECT WHERE id="..."` запрос по Primary Key в PostgreSQL, чтобы поменять статус заявки на `WAITING`.
6. Если консультант успел забрать клиента вовремя, сервис просто удаляет таймер из Redis, преждевременно отменяя эскалацию.

### Дополнительные сценарии Redis:
* **Rate Limiting:** Интегрирован прямо в Spring Cloud Gateway. Хранит корзины токенов (Token Bucket) по IP/Пользователю. Надежно защищает всю систему от внешнего спама.
* **Аналитический Кэш:** Вычисление сложных дашбордов в `Analytics Service` кэшируется в Redis на минуты (`@Cacheable`), что позволяет мобильному приложению Менеджера летать без перегрузки TimescaleDB аналитическими запросами.

---

## 7. Обработка конкурентных заявок (Protection from Race Condition)

Когда 5 консультантов отдела одновременно получают пуш, они все могут в одну и ту же миллисекунду нажать на кнопку *"Принять заявку"* на своих телефонах.
Для защиты системы от **Race Condition (Состояние гонки)** используется механизм **Optimistic Locking (Оптимистичная блокировка БД)**.

### Техническое устройство блокировки
В JPA/Hibernate-сущности Заявки на бэкенде добавлено поле:
```java
@Version
private Long version;
```

**Сценарий:**
1. Оба процесса `Request Service` (например, обрабатывающие запросы Василия и Ивана) достают из БД заявку клиента. Версия заявки `version = 1`.
2. Поток Василия успевает сгенерировать коммит на миллисекунду раньше. Hibernate превращает его в SQL:
   `UPDATE requests SET status='ASSIGNED', user_id='VASYA_ID', version=2 WHERE request_id='X' AND version=1;`
   БД успешно обновляет 1 строку. Транзакция Василия успешна.
3. Поток Ивана в следующую миллисекунду делает коммит:
   `UPDATE requests SET status='ASSIGNED', user_id='IVAN_ID', version=2 WHERE request_id='X' AND version=1;`
4. СУБД (PostgreSQL) возвращает ответ: `Обновлено 0 строк`, так как заявки с `version=1` больше физически не существует.
5. Для Ивана `Request Service` выбрасывает `OptimisticLockException`, транзакция обрывается, и на телефон Ивана улетает JSON-ошибка: *"К сожалению, эту заявку только что взял другой консультант"*. 

Данный подход исключает необходимость ставить тяжелые пессимистичные блокировки (`FOR UPDATE` на уровне всей строки в СУБД) и обеспечивает максимальную пропускную способность (Throughput) системы.

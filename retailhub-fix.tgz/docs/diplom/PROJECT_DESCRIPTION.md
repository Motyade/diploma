# RetailHub — Подробное описание проекта

## 1. Что такое RetailHub

RetailHub — это event-driven платформа для диспетчеризации консультантов в розничных магазинах. Клиент приходит в магазин, сканирует QR-код на полке, и система автоматически вызывает свободного консультанта нужного отдела. Если консультант не приходит вовремя — система эскалирует ситуацию менеджеру.

Платформа построена на микросервисной архитектуре: 7 независимых backend-сервисов + API Gateway + веб-приложение, общающихся через Apache Kafka. Каждый сервис имеет собственную базу данных (принцип database-per-service), что обеспечивает полную автономность — если один сервис упал, остальные продолжают работать.

### Основной пользовательский сценарий

1. **Клиент** сканирует QR-код телефоном → открывается веб-страница
2. Система создаёт **заявку на обслуживание** и привязывает её к отделу
3. **Консультанты** отдела мгновенно получают push-уведомление на мобильное приложение
4. Консультант нажимает «Взять заявку» → клиент видит, что помощь идёт
5. Консультант завершает обслуживание → заявка закрыта
6. Если никто не берёт заявку **3 минуты** — повторное уведомление
7. Если **5 минут** — эскалация менеджеру магазина

### Роли в системе

- **Клиент** — посетитель магазина, без регистрации, идентифицируется session-токеном
- **Консультант** — сотрудник магазина, работает на смене, привязан к отделам
- **Менеджер** — управляющий магазином, видит аналитику и получает эскалации

---

## 2. Архитектура системы

### 2.1 Микросервисы

Система состоит из 8 компонентов (7 backend-сервисов + фронтенд):

| Сервис | Порт | Назначение | Технология |
|--------|------|-----------|------------|
| **API Gateway** | 8080 | Единая точка входа, JWT-валидация, маршрутизация | Spring WebFlux |
| **Auth Service** | 8081 | Аутентификация, выпуск JWT-токенов | Spring Boot + JPA |
| **Store Service** | 8082 | Магазины, отделы, QR-коды | Spring Boot + JPA |
| **User Service** | 8083 | Сотрудники, смены, штрафы | Spring Boot + JPA |
| **Request Service** | 8084 | Заявки, SLA-контроль | Spring Boot + JPA + Redis |
| **Notification Service** | 8085 | Push-уведомления, WebSocket | Spring Boot + WebSocket |
| **Analytics Service** | 8086 | Дашборды, статистика | Spring Boot + JPA |
| **Web App** | 80 | Лендинг, QR-страница | nginx + HTML |

### 2.2 Инфраструктура

| Компонент | Версия | Назначение |
|-----------|--------|-----------|
| **PostgreSQL** | 17 | Основная СУБД (6 отдельных баз данных) |
| **Apache Kafka** | Confluent 7.8.0 | Шина событий для межсервисного общения |
| **Redis** | 7 Alpine | SLA delay queue, кэширование |
| **Zookeeper** | Confluent 7.8.0 | Координатор для Kafka |
| **Docker** | — | Контейнеризация всех компонентов |
| **Flyway** | 10.7.1 | Миграции схем баз данных |

### 2.3 Принцип взаимодействия

Главный архитектурный принцип: **между микросервисами нет прямых HTTP-вызовов**. Вся коммуникация идёт через Kafka-события. Это означает:

- Если User Service упал — Request Service продолжает работать, используя **локальную реплику** данных пользователей
- Нет каскадных сбоев — один упавший сервис не тянет за собой остальные
- Каждый сервис можно масштабировать и деплоить независимо

Есть три Kafka-топика:
- `store-events` — события магазинов, отделов, QR-кодов (продюсер: Store Service)
- `user-events` — события пользователей, смен, статусов (продюсер: User Service)
- `request-events` — события заявок (продюсер: Request Service)

---

## 3. Стек технологий

### 3.1 Java 21 + Spring Boot 4.0.2

Почему Java 21:
- Виртуальные потоки (Project Loom) — более эффективная обработка одновременных запросов
- Pattern matching, records — более лаконичный код
- Долгосрочная поддержка (LTS)

Почему Spring Boot:
- Самый зрелый фреймворк для microservices в Java-экосистеме
- Автоконфигурация — минимум boilerplate-кода
- Встроенная поддержка Kafka, Redis, JPA, WebSocket
- Огромная экосистема и документация

Пример: для подключения Kafka достаточно добавить зависимость `spring-kafka` и написать 10 строк конфигурации в `application.yaml`:

```yaml
spring:
  kafka:
    bootstrap-servers: kafka:9092
    producer:
      key-serializer: org.apache.kafka.common.serialization.StringSerializer
      value-serializer: org.springframework.kafka.support.serializer.JsonSerializer
```

### 3.2 PostgreSQL 17

Почему PostgreSQL:
- Надёжная реляционная СУБД с поддержкой JSONB (для хранения событий в outbox)
- Поддержка UUID как native-тип данных
- Расширения (TimescaleDB для аналитики совместим с PostgreSQL)
- Бесплатная, open source

Каждый сервис имеет **свою отдельную базу данных** (database-per-service):
- `auth_db` — credentials (учётные данные)
- `store_db` — stores, departments, qr_codes
- `user_db` — users, shifts, department_employees + реплики stores/departments
- `request_db` — requests, outbox_events + реплики QR/users
- `notification_db` — notifications, user_devices + реплики users
- `analytics_db` — fact_requests, dim_stores, dim_departments, dim_users

Базы создаются при первом запуске через `init-databases.sql`:

```sql
CREATE DATABASE auth_db;
CREATE DATABASE store_db;
CREATE DATABASE user_db;
CREATE DATABASE request_db;
CREATE DATABASE notification_db;
CREATE DATABASE analytics_db;
```

### 3.3 Apache Kafka

Почему Kafka (а не RabbitMQ или REST):
- **Гарантия порядка** — события одной заявки всегда обрабатываются по порядку (ключ = requestId → один partition)
- **Сохранение истории** — события не удаляются после прочтения, их можно перечитать
- **Множество подписчиков** — одно событие читают несколько сервисов одновременно (fan-out)
- **Пропускная способность** — миллионы сообщений в секунду

Пример: когда Request Service создаёт заявку, он публикует событие `REQUEST_CREATED` в топик `request-events`. Это событие читают одновременно:
- **User Service** — чтобы отслеживать активность
- **Notification Service** — чтобы отправить push-уведомление консультантам
- **Analytics Service** — чтобы записать факт создания заявки

Ни один из этих сервисов не знает друг о друге — они просто подписаны на один топик.

### 3.4 Redis

Почему Redis:
- SLA Delay Queue — невозможно реализовать через Kafka (нет delayed delivery)
- Операция ZADD/ZRANGEBYSCORE за O(log N) — идеально для очереди отложенных задач
- Один контейнер 5 МБ RAM решает 4 задачи

Где используется Redis:
1. **SLA Delay Queue** (Request Service) — очередь отложенных проверок заявок
2. **Rate Limiting** (API Gateway) — ограничение количества запросов
3. **Кэширование** (Analytics Service) — кэш дашбордов

Подробное описание — в отдельном документе `REDIS_ARCHITECTURE.md`.

### 3.5 Docker + Docker Compose

Все компоненты системы упакованы в Docker-контейнеры. Это обеспечивает:
- Одинаковое окружение на dev/staging/prod
- Запуск всей системы одной командой: `docker compose up -d`
- Изоляция: каждый сервис работает в своём контейнере
- Простое масштабирование: `docker compose up --scale request-service=3`

Каждый Java-сервис собирается через multi-stage Dockerfile:

```dockerfile
FROM maven:3.9-eclipse-temurin-21 AS build
WORKDIR /workspace
COPY pom.xml .
RUN mvn -N install -q
COPY shared/event-contracts shared/event-contracts
RUN mvn -f shared/event-contracts/pom.xml install -DskipTests -q
COPY auth-service/pom.xml auth-service/pom.xml
COPY auth-service/src auth-service/src
RUN mvn -f auth-service/pom.xml package -DskipTests -q

FROM eclipse-temurin:21-jre-alpine
WORKDIR /app
COPY --from=build /workspace/auth-service/target/*.jar app.jar
EXPOSE 8081
ENTRYPOINT ["java", "-jar", "app.jar"]
```

Первый этап (`build`) компилирует Java-код с помощью Maven. Второй этап берёт только собранный JAR и минимальный JRE. Это уменьшает размер образа с ~1 ГБ до ~450 МБ.

### 3.6 Flyway — миграции БД

Каждый микросервис управляет схемой своей БД через Flyway. Миграции — это SQL-файлы с версионированными именами:

```
V1__init_store_schema.sql
V2__add_department_index.sql
```

Flyway запускается отдельным контейнером перед стартом каждого сервиса:

```yaml
flyway-store:
  image: flyway/flyway:10.7.1-alpine
  command: -url=jdbc:postgresql://postgres:5432/store_db ... migrate
  volumes:
    - ./store-service/src/main/resources/db/migration:/flyway/sql
```

Это гарантирует, что схема БД всегда актуальна перед стартом приложения.

---

## 4. Детальное описание микросервисов

### 4.1 API Gateway

**Назначение:** единая точка входа для всех клиентских запросов.

**Что делает:**
- Принимает HTTP-запрос от мобилки или браузера
- Проверяет JWT-токен (если запрос требует аутентификации)
- Извлекает из токена `userId`, `role`, `storeId` и добавляет их в заголовки: `X-User-Id`, `X-Store-Id`, `X-Role`
- Перенаправляет запрос на нужный микросервис

**Маршрутизация:**

| Путь | Целевой сервис |
|------|---------------|
| `/api/v1/auth/**` | Auth Service (8081) |
| `/api/v1/stores/**`, `/api/v1/departments/**`, `/api/v1/qr-codes/**` | Store Service (8082) |
| `/api/v1/users/**`, `/api/v1/shifts/**` | User Service (8083) |
| `/api/v1/requests/**` | Request Service (8084) |
| `/api/v1/notifications/**`, `/api/v1/devices/**` | Notification Service (8085) |
| `/api/v1/analytics/**` | Analytics Service (8086) |
| `/ws/**` | Notification Service (8085) — WebSocket |

**Технология:** Spring WebFlux (реактивный стек на Netty). Выбран реактивный стек, потому что Gateway — это прокси: он не делает тяжёлых вычислений, а просто перенаправляет запросы. WebFlux обрабатывает тысячи одновременных соединений без создания отдельного потока на каждое.

**JWT-валидация:**

```java
@Override
public Mono<Void> filter(ServerWebExchange exchange, WebFilterChain chain) {
    String path = exchange.getRequest().getPath().value();
    if (isPublicPath(path)) return chain.filter(exchange);  // публичные пути без JWT

    String authHeader = exchange.getRequest().getHeaders().getFirst("Authorization");
    if (authHeader == null || !authHeader.startsWith("Bearer ")) {
        return chain.filter(exchange);  // нет токена — пропускаем
    }

    Claims claims = Jwts.parser().verifyWith(signingKey).build()
        .parseSignedClaims(authHeader.substring(7)).getPayload();

    // Добавляем данные из JWT в заголовки для downstream-сервисов
    ServerHttpRequest mutated = exchange.getRequest().mutate()
        .header("X-User-Id", claims.getSubject())
        .header("X-Role", claims.get("role", String.class))
        .header("X-Store-Id", String.valueOf(claims.get("storeId")))
        .build();

    return chain.filter(exchange.mutate().request(mutated).build());
}
```

Публичные пути (без JWT): `/auth/login`, `/auth/refresh`, `/qr-codes/scan/`, `/requests` (создание заявки), `/requests/{id}/cancel`, `/requests/{id}/remind`, `/requests/{id}/reassign`.

### 4.2 Auth Service

**Назначение:** аутентификация сотрудников.

**Эндпоинты:**
- `POST /api/v1/auth/login` — вход по номеру телефона + пароль → возвращает access + refresh токены
- `POST /api/v1/auth/refresh` — обновление access-токена по refresh-токену
- `GET /api/v1/auth/me` — профиль текущего пользователя

**Как работает JWT:**
- При логине Auth Service проверяет пароль через BCrypt
- Генерирует JWT с полями: `sub` (userId), `role` (MANAGER/CONSULTANT), `storeId`
- Access-токен живёт 15 минут, refresh-токен — 7 дней
- Подпись через HMAC-SHA (HS256) с общим секретом

**Откуда берутся учётные данные:**
Auth Service хранит таблицу `credentials` с логинами/паролями. Но создаёт и обновляет записи не через REST, а через Kafka-события: когда User Service создаёт нового сотрудника, он публикует `USER_CREATED` → Auth Service слушает этот топик и создаёт credential-запись.

```
User Service → Kafka (user-events) → Auth Service → INSERT INTO credentials
```

Это пример паттерна **Event-Carried State Transfer** — данные передаются через события, а не через прямые HTTP-вызовы.

### 4.3 Store Service

**Назначение:** управление организационной структурой магазина.

**Что хранит:**
- **Магазины** (stores) — название, адрес, часовой пояс
- **Отделы** (departments) — название, описание, привязка к магазину
- **QR-коды** (qr_codes) — уникальный токен, привязка к отделу, статус (активен/деактивирован)

**Эндпоинты:**
- CRUD для магазинов: `POST/GET/PUT /stores`
- CRUD для отделов: `POST/GET/PUT/DELETE /departments`
- QR-коды: `POST/GET/DELETE /qr-codes`
- Сканирование QR: `GET /qr-codes/scan/{token}` — публичный endpoint, возвращает название отдела и магазина

**Kafka-события:**
При каждом изменении Store Service публикует события в топик `store-events`:
- `STORE_CREATED`, `STORE_UPDATED`
- `DEPARTMENT_CREATED`, `DEPARTMENT_UPDATED`, `DEPARTMENT_DELETED`
- `QR_CODE_CREATED`, `QR_CODE_DEACTIVATED`

Эти события потребляют User Service (для реплики) и Request Service (для реплики QR-кодов).

### 4.4 User Service

**Назначение:** управление сотрудниками и сменами.

**Что хранит:**
- **Сотрудники** (users) — ФИО, телефон, роль, статус (OFFLINE/ACTIVE/BUSY)
- **Смены** (shifts) — начало, конец, количество штрафов
- **Привязка к отделам** (department_employees) — какой консультант в каких отделах может работать

**Ключевая логика — управление статусом:**
- Консультант начинает смену → статус `ACTIVE`
- Консультант взял заявку → User Service получает Kafka-событие `REQUEST_ASSIGNED` → статус `BUSY`
- Консультант завершил заявку → событие `REQUEST_COMPLETED` → статус обратно `ACTIVE`
- Консультант завершает смену → статус `OFFLINE`

**Штрафы:**
- `REQUEST_REASSIGNED` (клиент запросил смену консультанта) → штраф +1 конкретному консультанту
- `REQUEST_ESCALATED` (SLA нарушен) → штраф +1 всем свободным консультантам отдела

**Реплики данных:**
User Service хранит локальные копии магазинов и отделов (`replica_stores`, `replica_departments`) из Store Service. Это нужно для валидации — например, при создании сотрудника нужно проверить, что магазин существует, не обращаясь к Store Service.

### 4.5 Request Service

**Назначение:** ядро системы — управление жизненным циклом заявок на обслуживание.

**Состояния заявки:**

```
CREATED → WAITING → ESCALATED
    ↓                    ↓
ASSIGNED → COMPLETED   ASSIGNED → COMPLETED
    ↓                    ↓
CANCELED              CANCELED
```

- `CREATED` — клиент создал заявку (сканировал QR)
- `WAITING` — прошло 3 минуты, никто не взял (автоматический переход)
- `ESCALATED` — прошло 5 минут, SLA нарушен (автоматический переход)
- `ASSIGNED` — консультант взял заявку в работу
- `COMPLETED` — обслуживание завершено
- `CANCELED` — клиент отменил заявку

**Защита от гонки (optimistic locking):**
Если два консультанта одновременно нажимают «Взять» на одну заявку, только один из них успеет:

```java
@Version
private Long version;  // Hibernate увеличивает при каждом UPDATE
```

Второй получит `OptimisticLockException` и увидит, что заявка уже занята.

**Реплики данных:**
Request Service не обращается напрямую к другим сервисам. Вместо этого хранит:
- `replica_qr_codes` — для создания заявки по QR-токену
- `replica_users` — для проверки статуса консультанта при назначении
- `replica_user_departments` — для проверки принадлежности консультанта к отделу

Реплики обновляются через Kafka consumers, слушающие `store-events` и `user-events`.

**Transactional Outbox:**
Вместо прямой отправки в Kafka, Request Service записывает событие в таблицу `outbox_events` в той же транзакции, что и бизнес-операцию:

```java
@Transactional
public Request createRequest(UUID qrToken) {
    Request saved = requestRepository.save(request);          // 1. Сохраняем заявку
    writeOutboxEvent(saved, RequestEvent.TYPE_CREATED, ...);  // 2. Записываем событие в outbox
    slaDelayService.scheduleWaitingCheck(saved.getId(), ...); // 3. Планируем SLA-таймер
    return saved;
}
```

Отдельный `OutboxPublisher` каждые 100 мс читает из `outbox_events` непубликованные записи и отправляет их в Kafka:

```java
@Scheduled(fixedDelay = 100)
public void publishPendingEvents() {
    List<OutboxEvent> events = outboxEventRepository
        .findTop100ByPublishedAtIsNullOrderByCreatedAtAsc();
    for (OutboxEvent event : events) {
        kafkaTemplate.send("request-events", event.getAggregateId().toString(), event.getPayload());
        event.setPublishedAt(OffsetDateTime.now());
        outboxEventRepository.save(event);
    }
}
```

**Преимущество Transactional Outbox:** если приложение упадёт между сохранением заявки и отправкой в Kafka, событие не потеряется — оно останется в `outbox_events` и будет опубликовано при следующем запуске.

### 4.6 SLA Delay Queue (Redis)

**Проблема:** нужно автоматически переводить заявку в статус WAITING через 3 минуты и в ESCALATED через 5 минут.

**Старый подход (монолит):** `@Scheduled(fixedRate = 15000)` — каждые 15 секунд полное сканирование таблицы `requests`. Проблемы:
- N+1 запрос к БД
- Бесполезная нагрузка при отсутствии заявок
- Неточность до 15 секунд
- Не масштабируется при нескольких инстансах

**Новый подход (Redis Sorted Set):**

```
Создание заявки:
  ZADD sla:timers (timestamp + 3мин) "WAITING:requestId"

Через 3 минуты SLA Worker:
  ZRANGEBYSCORE sla:timers 0 {now}  → ["WAITING:requestId"]
  ZREM sla:timers "WAITING:requestId"  → атомарное удаление
  SELECT request WHERE id = requestId  → проверка: ещё CREATED?
  UPDATE status = WAITING
  ZADD sla:timers (timestamp + 2мин) "ESCALATED:requestId"

При назначении консультанта:
  ZREM sla:timers "WAITING:requestId" "ESCALATED:requestId"
```

SLA Worker опрашивает Redis (не PostgreSQL) каждую секунду. Redis ZRANGEBYSCORE на пустом множестве = O(1). При 10000 активных заявок — всё ещё мгновенно.

Атомарность `ZREM` гарантирует, что при нескольких инстансах Request Service только один обработает каждый таймер.

### 4.7 Notification Service

**Назначение:** доставка уведомлений через push (FCM) и WebSocket.

**Как работает:**
1. Kafka consumer получает событие из `request-events` (например, `REQUEST_CREATED`)
2. `NotificationRouter` определяет получателей и каналы:

| Событие | Кому | Как |
|---------|------|-----|
| REQUEST_CREATED | Консультанты отдела (ACTIVE) | FCM push + WebSocket |
| REQUEST_WAITING | Консультанты отдела (ACTIVE) | FCM push + WebSocket |
| REQUEST_ESCALATED | Менеджер магазина | FCM push + WebSocket |
| REQUEST_ASSIGNED | Клиент | WebSocket |
| REQUEST_COMPLETED | Клиент | WebSocket |
| REQUEST_REMINDED | Назначенный консультант | FCM push |
| REQUEST_REASSIGNED | Консультанты отдела | FCM push + WebSocket |
| REQUEST_CANCELED | Назначенный консультант | FCM push |

3. Для определения получателей используются реплики пользователей (`replica_users`, `replica_user_departments`)
4. FCM push отправляется через Firebase Cloud Messaging (пока placeholder-реализация)
5. WebSocket сообщение рассылается через STOMP

**WebSocket-каналы:**
- `/topic/store/{storeId}/requests` — менеджер подписывается и видит все заявки магазина
- `/topic/department/{departmentId}/requests` — консультант видит заявки своего отдела
- `/queue/request/{requestId}` — клиент следит за статусом своей заявки

**Пример подключения на JavaScript:**

```javascript
const socket = new SockJS('http://185.221.199.141:8085/ws');
const stompClient = Stomp.over(socket);
stompClient.connect({}, () => {
    stompClient.subscribe('/topic/department/2222-.../requests', (msg) => {
        const update = JSON.parse(msg.body);
        // Новая заявка или изменение статуса — обновить UI
    });
});
```

### 4.8 Analytics Service

**Назначение:** бизнес-аналитика и KPI.

**Модель данных (звёздная схема):**
- **Fact table:** `fact_requests` — каждая заявка со всеми временными метками (создана, назначена, завершена, время ожидания, время обслуживания)
- **Dimensions:** `dim_stores`, `dim_departments`, `dim_users`

**Эндпоинты:**
- `GET /analytics/dashboard?period=today` — сводка: количество заявок, среднее время ответа, rate эскалаций
- `GET /analytics/consultants?dateFrom=...&dateTo=...` — рейтинг консультантов
- `GET /analytics/consultants/{userId}` — детальная статистика одного консультанта
- `GET /analytics/requests?...` — история заявок с фильтрами

**Как заполняется:**
Analytics Service слушает ВСЕ три Kafka-топика и строит денормализованные данные:
- `REQUEST_CREATED` → INSERT в fact_requests
- `REQUEST_ASSIGNED` → UPDATE assigned_at, вычисление response_time_seconds
- `REQUEST_COMPLETED` → UPDATE completed_at, вычисление service_time_seconds
- `STORE_CREATED` → INSERT в dim_stores
- `USER_CREATED` → INSERT в dim_users

**Оптимизация для мобильных устройств:**
- Предвычисленные агрегаты — мобилка получает готовые числа
- HTTP-кэширование через Redis
- Лёгкий JSON без лишних полей

### 4.9 Web App

Статический веб-сайт: лендинг RetailHub + клиентская страница при сканировании QR. Раздаётся через nginx. Проксирует API-запросы через Gateway.

---

## 5. Паттерны и архитектурные решения

### 5.1 Event-Driven Architecture (EDA)

Вся межсервисная коммуникация через события. Сервисы не знают друг о друге — они знают только о Kafka-топиках.

**Преимущества:**
- Слабая связанность (loose coupling)
- Устойчивость к отказам
- Возможность replay событий
- Естественная поддержка аудита (все события сохраняются)

### 5.2 Event-Carried State Transfer

Каждый сервис хранит локальные реплики нужных данных. Реплики обновляются через Kafka consumers.

**Пример:** Request Service нужно проверить статус консультанта при назначении заявки. Вместо HTTP-вызова к User Service, он читает из своей таблицы `replica_users`:

```
User Service обновляет статус → публикует UserStatusChanged → Kafka →
→ Request Service consumer → UPDATE replica_users SET current_status = 'ACTIVE'
```

При назначении:

```java
ReplicaUser consultant = userRepository.findById(consultantId)
    .orElseThrow(() -> new RuntimeException("Консультант не найден"));
if ("OFFLINE".equals(consultant.getCurrentStatus())) {
    throw new RuntimeException("Консультант не на смене");
}
```

Нет сетевого вызова, нет зависимости от доступности User Service.

### 5.3 Transactional Outbox

Гарантирует exactly-once семантику между БД и Kafka. Событие записывается в таблицу `outbox_events` в той же транзакции, что и бизнес-данные. Если транзакция откатится — событие тоже не будет записано.

### 5.4 Database-per-Service

Каждый сервис владеет своей БД. Прямой доступ к чужим данным запрещён. Это обеспечивает:
- Независимость схем — можно менять структуру без согласования
- Независимое масштабирование — один сервис может использовать PostgreSQL, другой — TimescaleDB
- Отсутствие блокировок — транзакции одного сервиса не влияют на другой

### 5.5 Optimistic Locking

Защита от гонки при назначении заявок. Поле `version` в таблице `requests` увеличивается при каждом UPDATE. Если два потока одновременно пытаются обновить одну заявку, один из них получит исключение.

### 5.6 SLA Delay Queue через Redis ZSET

Замена неэффективного polling БД на очередь отложенных сообщений через Redis Sorted Set. Подробное описание — в разделе 4.6 и отдельном документе `REDIS_ARCHITECTURE.md`.

---

## 6. Безопасность

### 6.1 JWT-аутентификация

- Сотрудники аутентифицируются через логин/пароль → получают JWT
- JWT валидируется на уровне API Gateway
- Из JWT извлекаются `userId`, `role`, `storeId` → передаются в заголовках downstream-сервисам
- Downstream-сервисы доверяют заголовкам от Gateway

### 6.2 Клиентская аутентификация

- Клиент (посетитель магазина) не регистрируется
- При создании заявки генерируется уникальный `clientSessionToken` (UUID)
- Этот токен используется для операций с заявкой: cancel, remind, reassign
- Без знания токена невозможно управлять чужой заявкой

### 6.3 Пароли

- Хранятся в виде BCrypt-хеша
- Никогда не передаются в открытом виде между сервисами
- Даже в Kafka-событии `USER_CREATED` пароль передаётся уже захешированным

---

## 7. Развёртывание

### 7.1 Запуск системы

```bash
cd /root/diplom
docker compose up -d
```

Порядок запуска (управляется через `depends_on` + `healthcheck`):
1. PostgreSQL, Redis, Zookeeper → запускаются первыми
2. Kafka → после Zookeeper
3. Flyway-миграции (6 штук) → после PostgreSQL healthy
4. Микросервисы → после Flyway завершения
5. Web App → после Gateway

### 7.2 Мониторинг

Проверка статуса всех контейнеров:

```bash
docker ps --format "table {{.Names}}\t{{.Status}}\t{{.Ports}}"
```

### 7.3 Доступные URL

| Ресурс | URL |
|--------|-----|
| Лендинг | http://185.221.199.141 |
| Swagger UI (REST API) | http://185.221.199.141:8180/swagger-ui.html |
| WebSocket API docs | http://185.221.199.141:8180/websocket-docs.html |
| API Gateway | http://185.221.199.141:8180 |

---

## 8. Тестирование

Тестовый скрипт `test-api.sh` покрывает 36 эндпоинтов:

| Фаза | Сервис | Тестов |
|------|--------|--------|
| 0 | Seed-данные | — |
| 1 | Auth Service | 4 |
| 2 | Store Service | 6 |
| 3 | User Service | 6 |
| 4 | Request Service | 7 |
| 5 | Notification Service | 3 |
| 6 | Analytics Service | 4 |
| 7 | Gateway Proxy | 5 |
| 8 | WebSocket | 1 |
| **Итого** | | **36** |

Скрипт создаёт seed-данные в БД, затем последовательно тестирует полный жизненный цикл: логин → создание заявки → назначение → завершение → отмена → аналитика.

---

## 9. Структура проекта

```
retailhub/
├── api-gateway/              # Reactive API Gateway (WebFlux)
│   ├── src/main/java/.../gateway/
│   │   ├── config/           # GatewayProperties, GatewayRoutingConfig, SwaggerProxyConfig
│   │   └── filter/           # JwtValidationFilter, ProxyHandler
│   └── src/main/resources/
│       ├── static/           # swagger-ui.html, websocket-docs.html
│       └── application.yaml
│
├── auth-service/             # Аутентификация (9 Java-файлов)
├── store-service/            # Магазины, отделы, QR (24 Java-файла)
├── user-service/             # Сотрудники, смены (22 Java-файла)
├── request-service/          # Заявки, SLA (22 Java-файла)
│   └── src/main/java/.../request/
│       ├── sla/              # SlaDelayService, SlaWorker, SlaRecoveryRunner
│       └── kafka/            # OutboxPublisher, StoreEventConsumer, UserEventConsumer
│
├── notification-service/     # Push, WebSocket (20 Java-файлов)
│   └── src/main/java/.../notification/
│       ├── websocket/        # WebSocketConfig, WebSocketNotifier
│       └── service/          # NotificationRouter, FcmService
│
├── analytics-service/        # Аналитика (17 Java-файлов)
├── web-app/                  # Лендинг (nginx + HTML)
│
├── shared/
│   └── event-contracts/      # Общие DTO событий Kafka (5 Java-файлов)
│       └── src/main/java/.../events/
│           ├── BaseEvent.java
│           ├── RequestEvent.java
│           ├── StoreEvent.java
│           ├── UserEvent.java
│           └── EventTopics.java
│
├── docs/diplom/              # Документация
├── docker-compose.yml        # 16 контейнеров
├── init-databases.sql        # Создание 6 БД
└── pom.xml                   # Родительский Maven POM
```

**Общее количество:** ~125 Java-файлов, 6 SQL-миграций, 7 Dockerfile, 1 docker-compose.yml.

# Redis в архитектуре RetailHub

## Обоснование выбора

Redis добавляется в инфраструктуру как единственный новый компонент (помимо уже существующих PostgreSQL, Kafka, Zookeeper). Один контейнер `redis:7-alpine` закрывает четыре задачи, для каждой из которых иначе пришлось бы писать workaround.

## Точки использования

### 1. SLA Delay Queue (Request Service)

**Задача:** при создании заявки запланировать проверку SLA через 3 минуты (CREATED → WAITING) и через 5 минут (WAITING → ESCALATED).

**Почему не Kafka:** Kafka проектировалась как лог с немедленной доставкой. Consumer получает сообщение сразу после записи в partition. Механизма "доставь через N минут" нет. Возможные workaround'ы:

| Подход | Проблема |
|--------|----------|
| Consumer читает, видит что рано, делает `Thread.sleep()` | Блокирует весь partition, другие сообщения не обрабатываются |
| Consumer кладёт обратно в retry-топик | Лишний трафик, сложная логика, сообщение перечитывается многократно |
| Kafka Streams с `punctuate()` | Overkill, тяжело в отладке, требует state store |
| Отдельные топики `sla-delay-3min` / `sla-delay-5min` | Всё равно нужен механизм задержки на стороне consumer |

**Решение: Redis Sorted Set (ZSET)**

```
ZADD sla:timers <timestamp_когда_обработать> <requestId:тип_проверки>
```

- `score` = Unix timestamp в миллисекундах, когда нужно обработать
- `member` = `"{requestId}:WAITING"` или `"{requestId}:ESCALATED"`

Извлечение "созревших" таймеров:

```
ZRANGEBYSCORE sla:timers 0 <текущий_timestamp> LIMIT 0 100
```

Атомарное удаление (гарантия что только один инстанс обработает):

```
ZREM sla:timers "{requestId}:WAITING"
```

**Характеристики:**

- O(log N) для ZADD и ZREM
- O(log N + M) для ZRANGEBYSCORE (M = количество "созревших")
- O(1) на пустом ZSET — нулевая нагрузка при отсутствии заявок
- Атомарность ZREM — безопасно при нескольких инстансах Request Service
- Точность до 1 секунды (вместо 15 секунд при `@Scheduled` polling)

**Жизненный цикл таймера:**

```
Создание заявки:
  ZADD sla:timers (now + 3min) "abc-123:WAITING"

Через 3 минуты SLA Worker:
  ZRANGEBYSCORE → получил "abc-123:WAITING"
  ZREM → удалил (атомарно)
  SELECT request WHERE id = abc-123 → status == CREATED? → UPDATE WAITING
  ZADD sla:timers (now + 2min) "abc-123:ESCALATED"

При назначении консультанта (assign):
  ZREM sla:timers "abc-123:WAITING" "abc-123:ESCALATED"
  (таймеры отменяются, эскалация не нужна)
```

### 2. API Gateway — Rate Limiting

**Задача:** ограничить количество запросов на клиента (token bucket / sliding window).

**Почему Redis:** Spring Cloud Gateway имеет встроенную интеграцию `RedisRateLimiter`. При нескольких инстансах Gateway за балансировщиком счётчики запросов должны быть в общем хранилище. In-memory rate limiter не работает в распределённой среде — каждый инстанс считает независимо.

**Реализация:**

```yaml
# application.yml API Gateway
spring:
  cloud:
    gateway:
      routes:
        - id: request-service
          uri: lb://request-service
          predicates:
            - Path=/api/v1/requests/**
          filters:
            - name: RequestRateLimiter
              args:
                redis-rate-limiter.replenishRate: 10   # запросов/сек
                redis-rate-limiter.burstCapacity: 20
                key-resolver: "#{@userKeyResolver}"
```

Redis хранит: `request_rate_limiter.{userId}.tokens` и `request_rate_limiter.{userId}.timestamp`.

### 3. API Gateway — кэш JWT Public Key

**Задача:** при RS256 JWT Gateway проверяет подпись через public key при каждом запросе.

**Решение:** public key кэшируется в Redis с TTL. При ротации ключей Auth Service публикует событие, Gateway инвалидирует кэш.

Это **опциональная** оптимизация. Альтернатива: in-memory кэш (`@Cacheable` с Caffeine). Redis предпочтительнее при нескольких инстансах Gateway для консистентности кэша.

### 4. Analytics Service — HTTP-кэширование

**Задача:** мобильное приложение часто запрашивает дашборд (`GET /analytics/dashboard`). Каждый раз гонять запрос в TimescaleDB неэффективно.

**Решение:** предвычисленные результаты кладутся в Redis с TTL:

```java
@Cacheable(value = "dashboard", key = "#storeId + ':' + #period")
public DashboardResponse getDashboard(UUID storeId, String period) {
    // Тяжёлый запрос в TimescaleDB — выполнится только при cache miss
}
```

TTL по периоду:
- "today" → TTL 60 секунд (данные быстро устаревают)
- "week" → TTL 10 минут
- "month" → TTL 1 час

**Альтернатива:** in-memory кэш (Caffeine). Redis предпочтительнее при нескольких инстансах Analytics Service.

## Конфигурация

```yaml
# docker-compose.yml
redis:
  image: redis:7-alpine
  ports:
    - "6379:6379"
  volumes:
    - redis-data:/data
  command: redis-server --appendonly yes  # AOF persistence для SLA таймеров
  healthcheck:
    test: ["CMD", "redis-cli", "ping"]
    interval: 5s
    timeout: 3s
    retries: 5
```

AOF persistence включен для SLA delay queue: при рестарте Redis таймеры не теряются. Дополнительно, Request Service выполняет recovery при старте (`@PostConstruct`) — пересоздаёт таймеры для заявок в статусах CREATED/WAITING.

## Итого

| Задача | Компонент | Критичность | Альтернатива без Redis |
|--------|-----------|-------------|----------------------|
| SLA Delay Queue | Request Service | Высокая | DB polling (хуже по N+1 и точности) или Kafka workaround (сложно) |
| Rate Limiting | API Gateway | Средняя | In-memory (не работает при нескольких инстансах) |
| JWT Key Cache | API Gateway | Низкая | In-memory Caffeine |
| Analytics Cache | Analytics Service | Средняя | In-memory Caffeine |

Redis — один легковесный контейнер (~5 MB RAM), который решает четыре инфраструктурные задачи. Основная причина его появления — SLA Delay Queue, для которой нет адекватной альтернативы в стеке Kafka + PostgreSQL.

# Диаграммы прецедентов (Use Cases)

Ниже представлены диаграммы прецедентов для основных ролей пользователей системы.

## 1. Актор: Консультант

```mermaid
usecaseDiagram
    actor "Консультант" as C

    package "Управление сменой" {
        usecase "Начать смену" as UC1
        usecase "Завершить смену" as UC2
        usecase "Просмотр статистики" as UC3
    }

    package "Обработка заявок" {
        usecase "Получить уведомление о заявке" as UC4
        usecase "Принять заявку" as UC5
        usecase "Завершить заявку" as UC6
        usecase "Просмотр списка уведомлений" as UC7
    }

    C --> UC1
    C --> UC2
    C --> UC3
    C --> UC4
    C --> UC5
    C --> UC6
    C --> UC7
```

## 2. Актор: Менеджер

```mermaid
usecaseDiagram
    actor "Менеджер" as M

    package "Управление магазином" {
        usecase "Управление отделами" as UM1
        usecase "Генерация QR-кодов" as UM2
        usecase "Деактивация QR-кодов" as UM3
    }

    package "Управление персоналом" {
        usecase "Регистрация сотрудника" as UM4
        usecase "Назначение компетенций" as UM5
    }

    package "Аналитика" {
        usecase "Просмотр дашборда магазина" as UM6
        usecase "Отчет по сотрудникам" as UM7
        usecase "Получение уведомлений об эскалации" as UM8
    }

    M --> UM1
    M --> UM2
    M --> UM3
    M --> UM4
    M --> UM5
    M --> UM6
    M --> UM7
    M --> UM8
```

## 3. Актор: Клиент

```mermaid
usecaseDiagram
    actor "Клиент" as CL

    package "Взаимодействие" {
        usecase "Сканировать QR-код" as UCL1
        usecase "Создать заявку" as UCL2
        usecase "Отслеживать статус (Polling)" as UCL3
        usecase "Напомнить о себе" as UCL4
        usecase "Сменить консультанта" as UCL5
    }

    CL --> UCL1
    CL --> UCL2
    CL --> UCL3
    CL --> UCL4
    CL --> UCL5
```

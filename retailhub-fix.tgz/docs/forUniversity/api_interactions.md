# Диаграммы взаимодействия (API)

Визуализация потоков данных между клиентом, сервером и базой данных.

## 1. Создание заявки (Create Request)

Клиент сканирует QR-код и создает заявку. Система уведомляет консультантов.

```mermaid
sequenceDiagram
    participant C as Client (Web)
    participant GW as API Gateway
    participant BE as Backend (Request Service)
    participant KA as Kafka
    participant NO as Backend (Notification Service)
    participant FCM as Firebase
    participant CO as Consultant App

    C->>GW: POST /requests {qr_token}
    GW->>BE: Forward Request
    BE->>BE: Validate QR & Store
    BE->>BE: Create Request (Status: CREATED)
    BE->>BE: Generate client_session_token
    BE->>KA: Publish Event: RequestCreated
    BE-->>C: 201 Created (client_session_token)
    
    KA->>NO: Consume: RequestCreated
    NO->>NO: Find Active Consultants in Dept
    NO->>FCM: Send Push Notification
    FCM->>CO: Push: "Новая заявка!"
```

## 2. Принятие заявки (Assign Request)

Консультант реагирует на уведомление и принимает заявку.
Если консультант не начал смену (`OFFLINE`), тот же endpoint `POST /requests/{id}/assign` возвращает отдельный HTTP-код `412`.

```mermaid
sequenceDiagram
    participant CO as Consultant App
    participant GW as API Gateway
    participant BE as Backend
    participant KA as Kafka
    participant C as Client (Web Polling)

    CO->>GW: POST /requests/{id}/assign
    GW->>BE: Forward
    BE->>BE: Check if Request is still CREATED
    BE->>BE: Update Request (Status: ASSIGNED)
    BE->>BE: Update Consultant (Status: BUSY)
    BE->>KA: Publish Event: RequestAssigned
    BE-->>CO: 200 OK
    
    C->>GW: GET /requests/{id}?session=... (Polling)
    GW->>BE: Check Status
    BE-->>C: 200 OK {status: ASSIGNED, consultant_name: "Иван"}
```

## 3. Эскалация (Timer Job)

Фоновый процесс проверяет просроченные заявки.

```mermaid
sequenceDiagram
    participant JOB as Timer / Scheduler
    participant BE as Backend
    participant KA as Kafka
    participant MA as Manager App

    JOB->>BE: Check overdue requests (> 5 min)
    BE->>BE: Find Requests with Status CREATED
    BE->>BE: Update Status -> ESCALATED
    BE->>KA: Publish Event: RequestEscalated
    
    KA->>BE: Consume: RequestEscalated
    BE->>MA: Send Push to Manager ("Alarm!")
```

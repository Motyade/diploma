# Структура Базы Данных

База данных реализована на PostgreSQL. Схема строго соответствует сущностям JPA (Java) и миграциям Flyway (`V1__init_schema.sql`, `V3__fix_request_status.sql`).

## ER-диаграмма

```mermaid
erDiagram
    STORES ||--|{ DEPARTMENTS : has
    DEPARTMENTS ||--|{ QR_CODES : contains
    STORES ||--|{ USERS : employs
    USERS ||--|{ SHIFTS : works
    USERS ||--|{ USER_DEVICES : holds
    USERS ||--|{ NOTIFICATIONS : receives
    USERS }|--|{ DEPARTMENT_EMPLOYEES : assigned
    DEPARTMENTS }|--|{ DEPARTMENT_EMPLOYEES : staff
    
    REQUESTS }|--|| STORES : belongs
    REQUESTS }|--|| DEPARTMENTS : in
    REQUESTS }|--|{ QR_CODES : origin
    REQUESTS }|--|{ USERS : assigned_to

    STORES {
        uuid id PK
        string name
        string address
        string timezone "default: Europe/Moscow"
        timestamp created_at
        timestamp updated_at
    }

    DEPARTMENTS {
        uuid id PK
        uuid store_id FK
        string name
        timestamp created_at
    }

    QR_CODES {
        uuid id PK
        uuid department_id FK
        uuid token "UNIQUE"
        string label
        boolean is_active "default: true"
        timestamp created_at
    }

    USERS {
        uuid id PK
        uuid store_id FK
        string phone_number "UNIQUE"
        string password_hash
        string first_name
        string last_name
        string role "MANAGER, CONSULTANT"
        string current_status "OFFLINE, ACTIVE, BUSY"
        timestamp created_at
        timestamp updated_at
    }

    DEPARTMENT_EMPLOYEES {
        uuid id PK
        uuid user_id FK
        uuid department_id FK
        timestamp assigned_at
    }

    SHIFTS {
        uuid id PK
        uuid user_id FK
        uuid store_id FK
        timestamp started_at
        timestamp ended_at "nullable"
        int penalties_count "default: 0"
        timestamp created_at
    }

    REQUESTS {
        uuid id PK
        uuid store_id FK
        uuid department_id FK
        uuid qr_code_id FK "nullable"
        uuid assigned_user_id FK "nullable"
        string status "CREATED, ASSIGNED, COMPLETED, ESCALATED"
        uuid client_session_token
        int escalation_level "0, 1, 2"
        timestamp created_at
        timestamp assigned_at "nullable"
        timestamp completed_at "nullable"
        timestamp escalated_at "nullable"
    }

    NOTIFICATIONS {
        uuid id PK
        uuid user_id FK
        string title
        text body
        string type
        jsonb payload
        boolean is_read "default: false"
        timestamp created_at
    }

    USER_DEVICES {
        uuid id PK
        uuid user_id FK
        string fcm_token
        string device_info
        timestamp created_at
    }
```

## Полное описание таблиц (Словарь данных)

### 1. stores (Магазины)
Центральная сущность для поддержки мульти-тенантности.
*   `id` (UUID, PK): Уникальный идентификатор магазина.
*   `name` (VARCHAR): Название (например, "Флагман на Тверской").
*   `address` (TEXT): Физический адрес.
*   `timezone` (VARCHAR): Часовой пояс магазина (например, 'Europe/Moscow'). Критично для корректного учета смен.
*   `created_at` (TIMESTAMP): Дата создания записи.
*   `updated_at` (TIMESTAMP): Дата последнего обновления.

### 2. departments (Отделы)
Зоны внутри магазина (ТВ, Кухни, Сад).
*   `id` (UUID, PK): Идентификатор отдела.
*   `store_id` (UUID, FK): Ссылка на магазин.
*   `name` (VARCHAR): Название отдела.
*   `created_at` (TIMESTAMP): Дата создания.

### 3. users (Сотрудники)
Единая таблица для менеджеров и консультантов.
*   `id` (UUID, PK): Идентификатор пользователя.
*   `store_id` (UUID, FK): Магазин, к которому приписан сотрудник.
*   `phone_number` (VARCHAR, UNIQUE): Логин пользователя.
*   `password_hash` (VARCHAR): Хеш пароля (BCrypt).
*   `first_name` (VARCHAR): Имя (отображается клиенту).
*   `last_name` (VARCHAR): Фамилия.
*   `role` (VARCHAR): Роль в системе (`MANAGER` или `CONSULTANT`).
*   `current_status` (VARCHAR): Оперативный статус (`OFFLINE`, `ACTIVE`, `BUSY`). Используется алгоритмом распределения заявок.
*   `created_at`, `updated_at` (TIMESTAMP): Метки времени.

### 4. department_employees (Компетенции)
Связь "Многие-ко-многим" между сотрудниками и отделами.
*   `id` (UUID, PK): Идентификатор связи.
*   `user_id` (UUID, FK): Сотрудник.
*   `department_id` (UUID, FK): Отдел, в котором он может работать.
*   `assigned_at` (TIMESTAMP): Когда была назначена компетенция.

### 5. shifts (Смены)
Учет рабочего времени ("Clock-in / Clock-out").
*   `id` (UUID, PK): Идентификатор смены.
*   `user_id` (UUID, FK): Сотрудник.
*   `store_id` (UUID, FK): Магазин (денормализация для ускорения аналитики).
*   `started_at` (TIMESTAMP): Начало смены.
*   `ended_at` (TIMESTAMP): Конец смены (NULL, если сотрудник работает сейчас).
*   `penalties_count` (INT): Количество сброшенных/просроченных заявок за эту смену.
*   `created_at` (TIMESTAMP): Дата записи.

### 6. qr_codes (QR-коды)
Точки входа для создания заявок.
*   `id` (UUID, PK): Внутренний идентификатор.
*   `department_id` (UUID, FK): Отдел, к которому привязан QR.
*   `token` (UUID, UNIQUE): Публичный токен, зашитый в URL QR-кода.
*   `label` (VARCHAR): Понятное описание места (например, "Стойка у входа").
*   `is_active` (BOOLEAN): Флаг активности (Soft delete).
*   `created_at` (TIMESTAMP): Дата генерации.

### 7. requests (Заявки)
Ядро системы диспетчеризации.
*   `id` (UUID, PK): Идентификатор заявки.
*   `store_id` (UUID, FK): Магазин.
*   `department_id` (UUID, FK): Отдел.
*   `qr_code_id` (UUID, FK): QR-код, через который создана заявка.
*   `assigned_user_id` (UUID, FK): Назначенный консультант (NULL, если заявка в очереди).
*   `client_session_token` (UUID): Временный токен сессии клиента (для Polling без авторизации).
*   `status` (VARCHAR): Текущее состояние (`CREATED`, `ASSIGNED`, `COMPLETED`, `ESCALATED`).
*   `escalation_level` (INT): Уровень эскалации (0 - норма, 1 - предупреждение, 2 - менеджер).
*   `created_at` (TIMESTAMP): Время создания.
*   `assigned_at` (TIMESTAMP): Время назначения консультанта.
*   `completed_at` (TIMESTAMP): Время завершения.
*   `escalated_at` (TIMESTAMP): Время перехода в статус ESCALATED.

### 8. notifications (Уведомления)
Хранилище отправленных уведомлений (Inbox).
*   `id` (UUID, PK): Идентификатор уведомления.
*   `user_id` (UUID, FK): Получатель.
*   `title` (VARCHAR): Заголовок Push-уведомления.
*   `body` (TEXT): Текст уведомления.
*   `type` (VARCHAR): Тип события (например, `REQUEST_CREATED`).
*   `payload` (JSONB): Дополнительные данные (request_id, deep link) в формате JSON.
*   `is_read` (BOOLEAN): Статус прочтения.
*   `created_at` (TIMESTAMP): Время отправки.

### 9. user_devices (Устройства)
Токены FCM для доставки Push-уведомлений.
*   `id` (UUID, PK): Идентификатор записи.
*   `user_id` (UUID, FK): Владелец устройства.
*   `fcm_token` (VARCHAR): Токен от Firebase Cloud Messaging.
*   `device_info` (VARCHAR): Информация об устройстве (модель, ОС).
*   `created_at` (TIMESTAMP): Дата регистрации токена.
